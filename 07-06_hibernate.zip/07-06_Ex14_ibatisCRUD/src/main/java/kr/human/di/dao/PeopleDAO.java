package kr.human.di.dao;

import java.sql.SQLException;
import java.util.List;

import kr.human.di.vo.PeopleVO;

/*
 * <!-- 1. 한개 얻기 -->
	<select id="selectByIdx" parameterClass="int" resultClass="peopleVO">
		<![CDATA[
			select * from people where idx = #idx#
		]]>
	</select>
	<!-- 2. 모두 얻기 -->
	<select id="selectList" resultClass="peopleVO">
		<![CDATA[
			select * from people order by idx desc
		]]>
	</select>
	<!-- 3. 저장하기 -->
	<insert id="insert" parameterClass="peopleVO">
		<![CDATA[
			insert into people
			(name, age)
			values
			(#name#, #age#)
		]]>
	</insert>
	<!-- 4. 수정하기 -->
	<update id="update" parameterClass="peopleVO">
		<![CDATA[
			update people set name=#name# , age=#age# where idx=#idx#
		]]>
	</update>
	<!-- 5. 삭제하기 -->
	<delete id="delete" parameterClass="int">
		<![CDATA[
			delete from people where idx=#idx#
		]]>
	</delete>
 */
public interface PeopleDAO {
	PeopleVO selectByIdx(int idx) throws SQLException;
	
	List<PeopleVO> selectList() throws SQLException;
	
	void insert(PeopleVO peopleVO) throws SQLException;
	
	void update(PeopleVO peopleVO) throws SQLException;
	
	void delete(int idx) throws SQLException;
}
